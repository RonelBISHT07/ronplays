---
name: Mono-Vanguard
colors:
  surface: '#f9f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f9f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f5'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e4'
  on-surface: '#1a1c1d'
  on-surface-variant: '#4c4546'
  inverse-surface: '#2f3132'
  inverse-on-surface: '#f0f0f2'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#0050cc'
  on-secondary: '#ffffff'
  secondary-container: '#0266ff'
  on-secondary-container: '#f9f7ff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1a1c1c'
  on-tertiary-container: '#838484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#dae1ff'
  secondary-fixed-dim: '#b3c5ff'
  on-secondary-fixed: '#001849'
  on-secondary-fixed-variant: '#003fa4'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#f9f9fb'
  on-background: '#1a1c1d'
  surface-variant: '#e2e2e4'
typography:
  headline-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
  section-gap: 120px
---

## Brand & Style

This design system is built for a premium gaming-centric audience that values precision, high-end hardware, and professional aesthetics. It draws heavy inspiration from industrial design—specifically the interplay between organic curves and rigid technical surfaces found in next-generation gaming consoles.

The core style is **Minimalist-Corporate**, leaning into high-contrast monochromatic visuals with a subtle "technological glow." The personality is composed and elite, avoiding the chaotic neon tropes of traditional "gamer" aesthetics in favor of a clean, gallery-like presentation. It evokes a sense of "premium performance" through generous whitespace, razor-sharp typography, and smooth, tactile transitions.

## Colors

The palette is strictly monochromatic to echo the stark contrasts of high-end industrial plastics. 

- **Primary (Black):** Used for heavy structural elements, primary text, and grounding the UI.
- **Secondary (Pulse Blue):** A high-vibrancy accent color used sparingly for interactive cues, progress indicators, and "active" states, mimicking the light-bar of a controller.
- **Neutral/Background:** A range of whites and cool grays (#F5F5F7, #E8E8ED) create the "chassis" of the interface, providing a clean canvas that feels airy and premium.
- **Surface Tints:** Use subtle 2-5% opacity black overlays on white surfaces to create depth without resorting to heavy drop shadows.

## Typography

Geist is the exclusive typeface for this design system. Its technical, geometric construction aligns perfectly with the brand's professional gaming focus.

- **Headlines:** Use tight letter-spacing and heavy weights for a "bold impact" look. 
- **Body:** Maintain generous line heights to ensure the "minimalist" feel isn't compromised by dense text blocks.
- **Labels:** Utilize uppercase tracking for utility text (metadata, categories) to provide a structural, navigational feel similar to hardware markings.

## Layout & Spacing

The design system utilizes a **Fixed Grid** model for desktop to maintain a cinematic, composed feel, while transitioning to a fluid model for mobile.

- **The 4px Baseline:** All spacing and sizing must be multiples of 4px.
- **Whitespace as Content:** Margin and padding should be intentional and "oversized." Avoid crowding elements; if a section feels busy, double the spacing.
- **Responsive Behavior:** 
    - **Desktop:** 12-column grid, max-width 1440px. 
    - **Tablet:** 8-column grid with reduced margins.
    - **Mobile:** 4-column fluid grid. Content should reflow vertically with increased padding between distinct modules to maintain the "premium" breathability.

## Elevation & Depth

Depth is communicated through physical layering and lighting metaphors rather than traditional shadows.

- **The "Inner Glow" Effect:** Instead of drop shadows, use a 1px inner border (stroke) of #FFFFFF on top of light gray surfaces to create a "beveled" hardware edge.
- **Glassmorphism:** Use high-diffusion backdrop blurs (40px+) for navigation bars and overlays. This mimics the translucent plastic elements of modern controllers.
- **Tonal Stacking:** Higher elevation levels are indicated by lighter background shades (e.g., Background: #F5F5F7 -> Card: #FFFFFF).
- **Shadows:** If used for critical pop-overs, shadows must be extremely diffused: `0 20px 40px rgba(0,0,0,0.04)`.

## Shapes

The shape language is "Calculated Softness." Elements should have visible curves that suggest ergonomic comfort, but retain enough structure to feel professional.

- **Primary UI Elements:** (Buttons, Cards, Inputs) use a consistent 0.5rem (8px) radius.
- **Feature Modules:** Larger layout sections or "Hero" containers can use `rounded-xl` (24px) to create a distinct, encapsulated look.
- **Icons:** Should be stroke-based (2px weight) with slightly rounded terminals to match the font and corner radii.

## Components

### Buttons
- **Primary:** Solid Black (#000000) with White text. On hover, apply a subtle glow or transition to a deep charcoal.
- **Secondary:** Transparent background with a 1.5px Black border.
- **Action:** For "Start" or "Live" actions, use Pulse Blue (#0066FF) as a background or a subtle underline glow.

### Cards
Cards should not have visible borders by default. Use tonal differences (White card on a #F5F5F7 background) and a very soft 1px inner stroke to define the edge.

### Input Fields
Inputs should be "recessed" or "flat." Use a light gray background (#E8E8ED) with no border. On focus, the field should gain a 1px Pulse Blue bottom-border and a subtle blue glow transition.

### Chips & Tags
Small, pill-shaped elements with light gray backgrounds and uppercase label-caps typography. These function as metadata markers for game genres or platform status.

### Lists
Lists should be high-contrast with significant vertical padding (at least 16px between items). Use thin #E8E8ED dividers that do not span the full width of the container.